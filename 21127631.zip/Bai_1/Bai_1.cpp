#include "NhanSu.h"

#include "GiangVien.h"
#include "TroGiang.h"
#include "MonHoc.h"

#include "NghienCuuVien.h"
#include "ChuyenVien.h"
#include "DuAn.h"


int main()
{
	vector<NhanSu*> list;
	GiangVien* a1 = new GiangVien;
	TroGiang* a2 = new TroGiang;
	NghienCuuVien* a3 = new NghienCuuVien;
	ChuyenVien* a4 = new ChuyenVien;
	list.push_back(a1);
	list.push_back(a2);
	list.push_back(a3);
	list.push_back(a4);
	for (int i = 0; i < list.size(); i++)
	{
		cout << "Chuc vu: " << list[i]->LoaiNhanSu() << endl;
		list[i]->Input();
		cout << endl;
	}
	long double totalSalary = 0;
	for (int i = 0; i < list.size(); i++)
	{
		totalSalary += list[i]->TinhLuong();
	}
	cout << "Tong luong phai tra : " << totalSalary << " VND\n";
	for (int i = 0; i < list.size(); i++)
	{
		delete list[i];
	}
	list.clear();

	return 0;
}