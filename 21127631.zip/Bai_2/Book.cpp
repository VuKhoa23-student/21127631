#include "Book.h"

Book::Book()
{
	BookName = "unknown";
	AuthorName = "unknown";
}
Book::Book(string BookName, string AuthorName)
{
	this->BookName = BookName;
	this->AuthorName = AuthorName;
}
void Book::Input()
{
	cout << "Nhap ten sach: ";
	getline(cin >> ws, BookName);
	cout << "Nhap ten tac gia: ";
	getline(cin >> ws, AuthorName);
}
void Book::Output()
{
	cout << "Ten sach: " << BookName << endl;
	cout << "Ten tac gia: " << AuthorName;
}

string Book::get_BookName()
{
	return BookName;
}