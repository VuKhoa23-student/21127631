#pragma once
#include <iostream>
#include <string>

using namespace std;
class Book
{
private:
	string BookName;
	string AuthorName;
public:
	Book();
	Book(string BookName, string AuthorName);
	void Input();
	void Output();
	string get_BookName();
};

