#pragma once
#include "HinhChuNhat.h"

class HinhVuong:public HinhChuNhat
{
public:
	void Output();
    void Input();
	HinhVuong();
	HinhVuong(int canh);
};

