#pragma once
#include <iostream>'

using namespace std;

class HinhChuNhat
{
protected:
	float dai, rong;
public:
	virtual void Output();
	virtual void Input();
	HinhChuNhat();
	HinhChuNhat(int dai, int rong);
	float ChuVi();
	float DienTich();
};

