#include "HinhChuNhat.h"

void HinhChuNhat::Input()
{
	cout << "Nhap chieu dai: ";
	cin >> dai;
	cout << "Nhap chieu rong: ";
	cin >> rong;
}
void HinhChuNhat::Output()
{
	cout << "Dai = " << dai << endl;
	cout << "Rong = " << rong;
}
HinhChuNhat::HinhChuNhat()
{
	dai = 1;
	rong = 1;

}
HinhChuNhat::HinhChuNhat(int dai, int rong)
{
	this->dai = dai;
	this->rong = rong;
}
float HinhChuNhat::ChuVi()
{
	return dai + rong + dai + rong;
}
float HinhChuNhat::DienTich()
{
	return dai * rong;
}
