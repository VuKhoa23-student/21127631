#include "HinhChuNhat.h"
#include "HinhVuong.h"
#include"Book.h"
#include "Library.h"

int main()
{
	cout << "( DEMO HINH VUONG/ HINH CHU NHAT)\n";
	HinhVuong A(2);
	HinhChuNhat B(2, 10);
	cout << "Chu vi hinh vuong = " << A.ChuVi() << endl;
	cout << "DIen tich hinh vuong = " << A.DienTich() << endl;
	cout << "Chu vi hinh chu nhat = " << B.ChuVi() << endl;
	cout << "Dien tich hinh chu nhat = " << B.DienTich() << endl << endl;

	cout << "( DEMO THU VIEN/ SACH ) \n";
	Library library;
	Book book1("Adventure time", "Danny Lowkey");
	Book book2("Superman", "Cristina Bella");
	Book book3("DAWM", "Kenny Newell");
	library.ThemSach(book1);
	library.ThemSach(book2);
	library.ThemSach(book3);
	cout << "Sau khi them sach vao thu vien \n";
	library.Output();
	cout << "Sau khi xoa cuon Superman khoi thu vien \n";
	library.XoaSach("Superman");
	library.Output();
}