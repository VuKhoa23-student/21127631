#pragma once
#include "Book.h"
#include <vector>

class Library
{
	vector<Book> listOfBook;
public:
	Library();
	Library(vector<Book> listOfBook);
	void Input();
	void Output();
	void ThemSach(Book book);
	void XoaSach(string bookName); // truyen vao ten cua sach can xoa
};

