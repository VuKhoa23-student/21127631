#include "Library.h"

Library::Library()
{
	listOfBook = {};
}

Library::Library(vector<Book> listOfBook)
{
	this->listOfBook = listOfBook;
}

void Library::Input()
{
	int temp_int;
	cout << "Nhap so sach can them: ";
	cin >> temp_int;
	for (int i = 0; i < temp_int; i++)
	{
		Book temp;
		temp.Input();
		listOfBook.push_back(temp);
	}
}

void Library::Output()
{
	for (int i = 0; i < listOfBook.size(); i++)
	{
		cout << i + 1 << ")\n";
		listOfBook[i].Output();
		cout << endl;
	}
}

void Library::ThemSach(Book A)
{
	listOfBook.push_back(A);
}

void Library::XoaSach(string bookName)
{
	for (int i = 0; i < listOfBook.size(); i++)
	{
		if (listOfBook[i].get_BookName().compare(bookName) == 0)
		{
			listOfBook.erase(listOfBook.begin() + i);
		}
	}
}