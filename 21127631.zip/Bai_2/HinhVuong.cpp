#include "HinhVuong.h"

void HinhVuong::Output()
{
	cout << "Canh = " << dai;
}
void HinhVuong::Input()
{
	cout << "Nhap canh: ";
	cin >> dai;
	rong = dai;
}
HinhVuong::HinhVuong()
{
	dai = rong = 1;
}
HinhVuong::HinhVuong(int canh)
{
	dai = canh;
	rong = canh;
}